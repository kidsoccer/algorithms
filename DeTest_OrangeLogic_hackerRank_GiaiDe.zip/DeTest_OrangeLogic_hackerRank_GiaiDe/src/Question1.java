import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Question1 {


    public static void main(String ...s) {
        // Question1 solution1 = new
        List<String> strings = new ArrayList<>(
                Arrays.asList(new String []{
                  "mghcdefg",
                  "mmlghdff",
                  "mmmmmghm"

                })
        );
        System.out
                .println(gemCharacter(strings));
    }


    public static int gemCharacter (List<String> items){
        int[] counter = new int['z' - 'a' + 1];
        for (String item : items){
            boolean[] visited = new boolean[counter.length];
            for (int i = 0; i < item.length(); i++) {
                int index = item.charAt(i) - 'a';
                if (!visited[index]) {
                    counter[index]++;
                    visited[index] = true;
                }
            }
        }
        int result = 0;
        for (int count : counter)
            if (count == items.size())
                result++;
        return result;

    }


}
