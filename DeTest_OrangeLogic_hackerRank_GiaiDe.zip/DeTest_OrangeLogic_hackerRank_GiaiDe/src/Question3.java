import java.util.*;

public class Question3 {

    public static int countPairs(List<Integer> arr, long k) {
        Set<Integer> array = new HashSet<>(arr);
        Map<Integer, Integer> counter = new HashMap<>();
        for (Integer i : arr){
            int count = counter.getOrDefault(i, 0);
            counter.put(i, count + 1);
        }
        int count = 0;
        Iterator<Integer> iterator = array.iterator();
        while (iterator.hasNext()){
            int value = iterator.next();
            int opposite = (int)(k - value);
            //neu chi co 1 so, ko tao ra sum duoc, thi ignore
            if (value == opposite && counter.get(value) < 2)
                continue;
            if (array.contains(opposite)){
                count++;
                iterator.remove();
            }
        }
        return count;
    }

    public static void main(String ...s){
        List<Integer> inputs = new ArrayList<Integer>(Arrays.asList(new Integer[]{1,3,46,1,3,9}));
        System.out.println(countPairs(inputs,47));
    }
}
