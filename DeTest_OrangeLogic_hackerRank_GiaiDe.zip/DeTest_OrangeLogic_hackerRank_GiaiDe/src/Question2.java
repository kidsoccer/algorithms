import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Question2 {

    public static void main(String ...s){

        List<List<Integer>> after = new ArrayList<>();

        List<Integer> arr1 = new ArrayList<>(Arrays.asList(new Integer[]{1,2}));
        after.add(arr1);
        arr1 = new ArrayList<>(Arrays.asList(new Integer[]{3,4}));
        after.add(arr1);
        System.out.println(findMatrix(after));
    }

    public static List<List<Integer>> findMatrix(List<List<Integer>> after){
        List<List<Integer>> result = new ArrayList<>();
        for (int i = 0; i < after.size(); i++)
            result.add(new ArrayList<>(after.get(i).size()));


        for (int row = 0; row < after.size(); row++){
            for (int col = 0; col < after.get(0).size(); col++){
                int top = getValue(after, row - 1, col);
                int left = getValue(after, row, col - 1);
                int cur = getValue(after, row, col);
                int topLeft = getValue(after, row - 1, col - 1);
                setValue(result, row, col, cur - (top + left) + topLeft);
            }
        }
        return result;
    }

    private static int getValue(List<List<Integer>> matrix, int row, int col){
        if (row < 0 || col < 0)
            return 0;
        return matrix.get(row).get(col);
    }

    private static void setValue(List<List<Integer>> matrix, int row, int col, int value){
        matrix.get(row).add(col, value);
    }
}
